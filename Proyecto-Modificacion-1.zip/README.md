# my-vue-cli

## Project setup
```
git clone https://github.com/JavierPinzon34/Plantilla-Vue-UTP.git
cd Plantilla-Vue-UTP
npm install
npm run serve
```

### Customize configuration
- See [Vue-Cli](https://cli.vuejs.org/config/).
- See [Vue-Router](https://router.vuejs.org/).
- See [Bootstrap-Vue](https://bootstrap-vue.org/).